﻿# Первый сценарий для Ren'Py — глава 1: «Повреждённая память»
#
# Установка:
# 1. Создайте проект в Ren'Py Launcher.
# 2. Откройте папку проекта -> game.
# 3. Замените содержимое script.rpy этим кодом.
# 4. Запустите проект.
#
# Пока вместо готовых иллюстраций используются цветовые фоны-заглушки.
# Позже их можно заменить файлами изображений: см. комментарии ниже.
# Растягивание изображений на весь экран
transform full_screen:
    xysize (config.screen_width, config.screen_height)


define m = Character("Марк Вейл", who_color = '#00CCFF')
image mark = "images/characters/01_Mark.png"
define s = Character("Сай Рен", who_color="#B58CFF")
image sai = "images/characters/04_Sai.png"
define system = Character("СИСТЕМА", who_color = '#FF4444')
image system = "images/characters/02_System.png"
define narrator = Character(None)
define i = Character("Доктор Итан Роу")
image itan = "images/characters/05_Dr.Itan.png"
define v = Character("Виктория Кейн")
image victoria = "images/characters/06_Victoria.png"

# Переменные решений. Они пригодятся в следующих главах.
default sai_trust = 0
default carrier_copied = False
default mark_revealed_profile = False
# Фоны и CG из папки game/images/
# Названия файлов должны совпадать с теми, что лежат в архиве.
image bg workshop = "images/03_workshop.png"
image bg city = "images/02_nova_rein_city.png"
image bg memory = "images/07_memory_fragment.png"
image bg dark = Solid("#050609")
image bg final = "images/12_final_workshop.png"

# Дополнительные иллюстрации (можно использовать в будущих сценах).
image cg mark = "images/04_mark_vale.png"
image cg carrier = "images/05_neural_carrier.png"
image cg system_lina = "images/06_system_alert_lina.png"
image cg mark_shocked = "images/08_mark_shocked.png"
image cg player_choice = "images/09_player_choice.png"
image cg helix = "images/10_helix_threat.png"
image cg countdown = "images/11_lockdown_countdown.png"

transform mark_position:
    crop (0, 0, 1024, 1100)
    zoom 0.65
    xalign 0.0
    yalign 1.0

transform system_position:
    crop (0, 0, 1024, 1100)
    zoom 0.65
    xalign 1.0
    yalign 1.0

# Пример подключения настоящего фона:
# Поместите файл workshop.png в game/images/
# и замените строку выше на:
# image bg workshop = "images/workshop.png"

label start:

    scene bg dark
    with fade

    centered "{size=38}{b}Apor1a.Protocol{/b}{/size}"
    centered "{size=20}Глава 1. Повреждённая память{/size}"
    pause 1.5

    scene bg city at full_screen
    with dissolve

    narrator "Нова-Рейн. 02:17."
    narrator "Город не спал. Он просто переводил сознание на ночной режим."
    narrator "Над улицами мерцали рекламные проекции, беспилотники скользили между небоскрёбами, а под землёй продолжали работать те, кому официальные системы давно отказали в доверии."
    narrator "Здесь можно было купить почти всё."
    narrator "Даже воспоминание, которого у тебя никогда не было."

    scene bg workshop at full_screen
    with fade

    narrator "Под одним из старых транспортных узлов находилась небольшая мастерская."
    narrator "На двери не было вывески. Только потёртый знак предупреждал: «Не подключать повреждённые носители без резервной копии»."
    
    show mark at mark_position with Dissolve(1.5)
    
    m "Ещё одна ночь, ещё одна чужая жизнь."
    m "Если повезёт, к утру я закончу восстановление и смогу оплатить аренду."

    narrator "Марк Вейл, двадцать шесть лет. Специалист по восстановлению повреждённых воспоминаний."
    narrator "По крайней мере, именно так он представлялся клиентам."

    narrator "На рабочем столе лежал небольшой нейроноситель. Его корпус был покрыт трещинами, а индикатор едва заметно мигал."

    m "Заказ без имени. Оплата внесена заранее. Никаких вопросов."
    m "Обычно это означает, что вопросы как раз будут."

    narrator "Марк подключил носитель к диагностическому модулю."

    # Здесь позже можно добавить анимацию интерфейса или отдельный экран сканирования.

    show system at system_position with Dissolve(1.5)

    system "ОБНАРУЖЕН ПОВРЕЖДЁННЫЙ НЕЙРОНОСИТЕЛЬ."
    system "Состояние данных: критическое."
    system "Владелец: ЛИНА МОРРОУ."
    system "Статус владельца: СВЕДЕНИЯ О СМЕРТИ ПОДТВЕРЖДЕНЫ."
    system "Дата смерти: пять лет назад."

    hide system at system_position with Dissolve(1.5)

    m "Лина Морроу?.."
    m "Я помню это имя. Бывшая исследовательница Helix Dynamics."
    m "По официальным данным, она погибла во время инцидента."

    narrator "Марк приблизил носитель к сканеру. На экране появились фрагменты повреждённой записи."
    narrator "Большая часть данных была зашифрована или разрушена. Но один фрагмент оставался доступен."

    scene bg memory at full_screen
    with dissolve

    narrator "На мгновение мастерская исчезла."
    narrator "Вместо неё возник белый коридор. Слишком яркий свет. Сигнал тревоги. Чьё-то дыхание рядом."

    show system at system_position with Dissolve(1.5)

    system "ФРАГМЕНТ ВОСПОМИНАНИЯ ВОССТАНОВЛЕН."
    system "Источник: ЛИНА МОРРОУ."
    system "СОВПАДЕНИЕ НЕЙРОННОГО ПРОФИЛЯ: 87,4%%."

    hide system at system_position with Dissolve(1.5)

    scene bg workshop at full_screen
    with vpunch

    show mark at mark_position with Dissolve(1.5)

    show system at system_position with Dissolve(1.5)

    m "Что?.."
    m "Восемьдесят семь процентов? Это ошибка."

    system "ОБНАРУЖЕН СВЯЗАННЫЙ НЕЙРОПРОФИЛЬ."
    system "ПРОФИЛЬ: MARK_VALE."
    system "СОВПАДЕНИЕ ПОДТВЕРЖДЕНО."

    hide system at system_position with Dissolve(1.5)

    narrator "Марк отодвинулся от стола."
    narrator "Носитель женщины, погибшей пять лет назад, был связан с его собственным нейропрофилем."

    m "Почему мои данные находятся на её носителе?"
    m "И почему система считает их совместимыми?"

    menu:
        "Сохранить восстановленный фрагмент и продолжить анализ.":
            $ carrier_copied = True
            $ mark_revealed_profile = True
            m "Сначала сделаю копию. Если система ошибается, я смогу это доказать."
            narrator "Марк создал локальную копию фрагмента. На экране появился новый файл с предупреждением о неизвестном источнике данных."
        "Отключить носитель и проверить его изолированно.":
            $ carrier_copied = False
            $ mark_revealed_profile = False
            m "Никаких дальнейших подключений, пока я не пойму, что происходит."
            narrator "Марк отключил кабель и перевёл носитель в изолированный режим. Но предупреждение о совпадении уже осталось в журнале системы."

    narrator "В этот момент экран погас."
    pause 0.4
    scene bg dark
    with dissolve

    show system at system_position with Dissolve(1.5)
    
    system "ВНЕШНИЙ ЗАПРОС ДОСТУПА."
    system "ИСТОЧНИК: HELIX DYNAMICS."
    system "ПРАВА ДОСТУПА ОТОЗВАНЫ."
    system "УДАЛЁННОЕ БЛОКИРОВАНИЕ НОСИТЕЛЯ ЧЕРЕЗ 10 СЕКУНД."

    hide system at system_position with Dissolve(1.5)

    scene bg workshop at full_screen
    with vpunch

    show mark at mark_position with Dissolve(1.5)

    m "Helix?.. Они не должны знать, что носитель здесь."

    narrator "Марк попытался отменить блокировку. Система не отвечала."
    narrator "На экране отсчитывались секунды."

    menu:
        "Попытаться обойти блокировку вручную.":
            $ sai_trust += 1
            m "Давай же... Ещё немного."
            narrator "Марк запустил аварийный протокол. Блокировка замедлилась, но полностью снять её не удалось."
            system "ПРЕДУПРЕЖДЕНИЕ: НЕСАНКЦИОНИРОВАННОЕ ВМЕШАТЕЛЬСТВО."
        "Срочно скопировать журнал соединений.":
            $ carrier_copied = True
            m "Сам носитель могут забрать. Но следы подключения должны остаться."
            narrator "Марк успел сохранить журнал соединений. В нём значился корпоративный сервер Helix Dynamics."
            show system at system_position with Dissolve(1.5)
            system "ЖУРНАЛ СОХРАНЁН."
            hide system at system_position with Dissolve(1.5)

    narrator "Носитель заблокировался. На его поверхности погас последний индикатор."
    narrator "Но перед отключением система успела вывести одну строку."

    show system at system_position with Dissolve(1.5)

    system "PALIMPSEST / SUBJECT 01 / M. VALE"

    hide system at system_position with Dissolve(1.5)

    show mark at mark_position with Dissolve(1.5)

    m "Палимпсест..."
    m "Что вы со мной сделали?"

    narrator "Марк знал только одного человека, который мог помочь разобраться в подобном взломе."

    m "Сай. Если кто-то и сможет добраться до этих архивов, то он."

    scene bg dark at full_screen
    with fade

    narrator "Марк открыл защищённый канал связи."
    narrator "На экране появилось имя: САЙ РЕН."

    # В следующей сцене начинается расследование вместе с Саем.
    # Здесь первая глава заканчивается на сюжетном крючке.

    centered "{size=30}{b}КОНЕЦ ПЕРВОЙ СЦЕНЫ{/b}{/size}"
    centered "{size=18}Продолжение: «Следы Палимпсеста»{/size}"

    jump chapter_2

    return