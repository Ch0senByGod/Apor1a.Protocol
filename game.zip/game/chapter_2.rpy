# Глава 2 — «Следы Палимпсеста»
# Поместите этот файл chapter2.rpy в папку game/ проекта Ren'Py.
# В конце первой главы, перед return, добавьте: call chapter2
# Использует персонажей m, s, system, narrator и переменные из главы 1.

image bg2 sai_hideout = "images/13_sai_hideout.png"
image bg2 archive = "images/14_helix_archive.png"
image bg2 glitch = "images/07_memory_fragment.png"

default sai_told_truth = False
default sai_data_debt_revealed = False
default archive_evidence_found = False
default palimpsest_name_found = False
default chapter2_finished = False
default sai_accused = False
default archive_watcher_detected = False

label chapter_2:

    scene bg dark
    with fade
    centered "{size=36}{b}Apor1a.Protocol{/b}{/size}"
    centered "{size=24}Глава 2. Следы Палимпсеста{/size}"
    pause 1.5

    scene bg2 sai_hideout:
        xysize (1920, 1080)

    with dissolve

    n "Нова-Рейн. 02:31."
    n "Защищённый канал несколько раз мигнул, прежде чем соединение установилось."
    n "На экране появился Сай Рен — знакомое лицо, освещённое холодным светом мониторов."
    
    show mark at mark_position with Dissolve(1.5)
    show sai at sai_position with Dissolve(1.5)
    
    s "Марк? Ты знаешь, который час?"
    m "Знаю. Мне нужна помощь."
    s "По голосу слышно. Что случилось?"
    m "Я получил нейроноситель Лины Морроу. На нём обнаружился фрагмент её памяти и мой нейропрофиль."
    s "Твой? Насколько сильное совпадение?"
    m "Восемьдесят семь целых четыре десятых процента."
    s "Это не похоже на обычное повреждение данных."
    m "Helix Dynamics попыталась удалённо заблокировать носитель."
    s "Тогда не подключай его к сети. Вообще."

    if memory_fragment_saved:
        m "У меня есть локальная копия фрагмента."
        s "Хорошо. Это может оказаться полезнее самого носителя."
    else:
        m "Копии фрагмента нет. Я отключил носитель до завершения анализа."
        s "Жаль. Но журнал соединений или остаточные данные всё ещё могут что-то показать."

    if profile_match_saved:
        s "Ты сохранил данные о совпадении профилей?"
        m "Да. Система подтвердила связь с моим профилем."
    else:
        s "Ты уверен, что правильно прочитал предупреждение?"
        m "Я отключил носитель, но строку о совпадении успел увидеть."

    menu:
        "Рассказать Саю о строке PALIMPSEST.":
            $ sai_told_truth = True
            $ sai_trust += 1
            show mark at mark_position with Dissolve(1.5)
            show sai at sai_position with Dissolve(1.5)
            m "Перед отключением появилась строка: PALIMPSEST / SUBJECT 01 / M. VALE."
            s "Палимпсест... Я слышал это название в закрытых каталогах Helix."
            m "Что это за проект?"
            s "Пока не знаю. Но теперь знаю, что искать."
        "Пока показать только журнал соединений.":
            $ sai_told_truth = False
            show mark at mark_position with Dissolve(1.5)
            show sai at sai_position with Dissolve(1.5)
            m "У меня есть след удалённого подключения Helix. Начнём с него."
            s "Ладно. Но если ты что-то недоговариваешь, это может осложнить работу."

    s "Пришли мне журнал. Только через одноразовый канал."
    m "Отправляю."

    scene bg2 archive:
        xysize (1920, 1080)

    with dissolve

    n "Через несколько минут Сай подключился к зеркалу старого корпоративного архива."
    n "Официальные серверы Helix не отвечали на прямые запросы. Но в сети оставались забытые копии каталогов и повреждённые индексы."

    show mark at mark_position with Dissolve(1.5)
    show sai at sai_position with Dissolve(1.5)

    s "Есть след. Сервер, который пытался заблокировать твой носитель, обращался к архивному узлу."
    m "Можешь открыть его?"
    s "Попробую. Если там активна защита, нас заметят."
    m "Они уже знают, что носитель у меня."
    s "Не обязательно знают, кто именно его открыл."

    show system at system_position1 with Dissolve(1.5)

    sys "УСТАНОВЛЕНО СОЕДИНЕНИЕ С НЕИЗВЕСТНЫМ АРХИВОМ."
    sys "УРОВЕНЬ ДОСТУПА: ОГРАНИЧЕННЫЙ."
    sys "ОБНАРУЖЕНЫ ПОВРЕЖДЁННЫЕ ЗАПИСИ."

    hide system at system_position1 with Dissolve(1.5)

    s "Вижу каталоги: медицинские отчёты, нейронные профили и внутренние протоколы."
    m "Ищи Лину Морроу."
    s "Уже."

    n "На экране появились десятки строк. Большинство записей были зашифрованы, часть — удалена."
    s "Нашёл упоминание Лины. Документ повреждён."
    m "Что удалось прочитать?"
    s "Фрагмент: «совместимость источников... реконструкция субъекта... резервный нейронный массив»."
    m "Субъект?"
    s "Здесь нет имени. Только номер."

    menu:
        "Попросить Сая восстановить медицинский фрагмент.":
            $ archive_evidence_found = True
            $ archive_watcher_detected = False
            
            show sai at sai_position with Dissolve(1.5)
            
            s "Попробую собрать документ из зеркальных копий."
            n "Сай сопоставил несколько повреждённых версий файла. Часть текста восстановилась."
            
            show system at system_position1 with Dissolve(1.5)
            
            sys "ФРАГМЕНТ ДОКУМЕНТА ВОССТАНОВЛЕН."
            sys "ПРОТОКОЛ: НЕЙРОННАЯ РЕКОНСТРУКЦИЯ."
            sys "СТАТУС: ПОСЛЕАВАРИЙНОЕ ВОССТАНОВЛЕНИЕ."
            
            hide system at system_position1 with Dissolve(1.5)
            show mark at mark_position with Dissolve(1.5)

            m "Послеаварийное..."
            s "Похоже, речь о человеке, которого пытались восстановить после катастрофы."
        "Сначала проверить, кто ещё подключён к архиву.":
            $ archive_evidence_found = False
            $ archive_watcher_detected = True

            show sai at sai_position with Dissolve(1.5)
            show mark at mark_position with Dissolve(1.5)

            s "Разумно. Секунду..."
            n "Сай обнаружил ещё один запрос, замаскированный под служебную проверку."

            show system at system_position1 with Dissolve(1.5)

            sys "ВНИМАНИЕ: ОБНАРУЖЕН ВТОРОЙ УДАЛЁННЫЙ СЕАНС."

            hide system at system_position1 with Dissolve(1.5)

            s "Кто-то наблюдает за архивом. Я не стану открывать документ, пока не закрою наш след."
            m "Успеешь?"
            s "Если повезёт. Но времени мало."

    $ palimpsest_name_found = True

    show sai at sai_position with Dissolve(1.5)
    show mark at mark_position with Dissolve(1.5)


    s "В индексе есть название проекта: PALIMPSEST."
    m "Значит, это не случайная строка на носителе."
    s "Проект помечен как закрытый и засекреченный."

    show system at system_position1 with Dissolve(1.5)

    sys "PALIMPSEST"
    sys "ТИП: ПРОЕКТ РЕКОНСТРУКЦИИ ЛИЧНОСТИ."
    sys "ИСТОЧНИКИ: НЕСКОЛЬКО НЕЙРОННЫХ ПРОФИЛЕЙ."
    sys "ДОСТУП: ТОЛЬКО ДЛЯ УПОЛНОМОЧЕННЫХ СОТРУДНИКОВ."

    hide system at system_position1 with Dissolve(1.5)

    m "Реконструкция личности..."
    s "Это больше, чем восстановление повреждённой памяти."
    m "Можно собрать человека из чужих воспоминаний?"
    s "Не знаю. Но именно на это намекает описание."
    m "И почему мой профиль связан с Линой?"
    s "Пока у нас больше вопросов, чем ответов."

    scene bg2 glitch:
        xysize (1920, 1080)

    with dissolve
    n "На мониторе на мгновение возникло изображение белого коридора."
    n "Марк узнал свет, холодные стены и резкий сигнал тревоги."
    n "Но воспоминание оборвалось прежде, чем он смог понять, видел ли это раньше."

    show sai at sai_position with Dissolve(1.5)
    show mark at mark_position with Dissolve(1.5)

    m "Я уже был там."
    s "Где?"
    m "В этом коридоре. Или мне кажется, что был."
    s "Не пытайся выдавить из себя воспоминание. Если запись повреждена, давление может усилить ошибки."
    m "Ты говоришь так, будто знаешь, что со мной произошло."
    s "Я знаю только то, что вижу в данных."

    scene bg2 sai_hideout:
        xysize (1920, 1080)
    with dissolve

    show sai at sai_position with Dissolve(1.5)
    show mark at mark_position with Dissolve(1.5)

    s "Есть ещё кое-что, Марк."
    m "Говори."
    s "Несколько лет назад я продавал обезличенные технические данные через посредника."
    m "При чём здесь это?"
    s "Я не знал, кто конечный покупатель. Но часть массива могла быть связана с нейронными профилями."
    m "Ты продал данные Helix?"
    s "Не напрямую. Я не могу подтвердить, что среди них был твой профиль."
    m "И всё же они могли выйти на меня через эти данные?"
    s "Могли. Я не знал, что их используют так."

    menu:
        "Обвинить Сая и потребовать объяснений.":
            $ sai_data_debt_revealed = True
            $ sai_trust -= 1
            $ sai_accused = True
            
            show sai at sai_position with Dissolve(1.5)
            show mark at mark_position with Dissolve(1.5)
            
            m "Ты понимаешь, что из-за этого они могли найти меня?"
            s "Понимаю. Если это так, я виноват, что не проверил покупателя."
            m "Мне нужно было услышать это раньше."
            s "Ты прав. Я должен был сказать."
        "Выслушать Сая и продолжить расследование.":
            $ sai_data_debt_revealed = True
            $ sai_trust += 1
            $ sai_accused = False
            
            show sai at sai_position with Dissolve(1.5)
            show mark at mark_position with Dissolve(1.5)
            
            m "Ты не знал, что данные используют так."
            s "Не знал. Но это не снимает с меня ответственности."
            m "Тогда поможешь выяснить, что именно ты продал."
            s "Да. И на этот раз я проверю каждый след."

    show sai at sai_position with Dissolve(1.5)
    show mark at mark_position with Dissolve(1.5)

    s "Я попробую восстановить список получателей старого массива."
    m "Сделай это."
    s "Но не сегодня. Наше соединение уже заметили."

    show system at system_position1 with Dissolve(1.5)

    sys "ПРЕДУПРЕЖДЕНИЕ: ВНЕШНИЙ МОНИТОРИНГ."
    sys "СЕАНС БУДЕТ ПРЕРВАН."

    hide system at system_position1 with Dissolve(1.5)

    n "Сай разорвал соединение и удалил временные ключи доступа."

    if archive_evidence_found:
        m "Послеаварийное восстановление... Значит, что-то произошло в лаборатории."
    else:
        m "У нас есть название проекта, но пока нет подробных доказательств."

    s "Марк, не доверяй воспоминанию только потому, что оно кажется настоящим."
    m "Почему?"
    s "Потому что кто-то мог работать с твоим нейропрофилем."

    scene bg dark
    with fade
    centered "{size=30}{b}КОНЕЦ ВТОРОЙ ГЛАВЫ{/b}{/size}"
    centered "{size=18}Продолжение: «Человек до аварии»{/size}"

    $ chapter2_finished = True

    call chapter_3

    return